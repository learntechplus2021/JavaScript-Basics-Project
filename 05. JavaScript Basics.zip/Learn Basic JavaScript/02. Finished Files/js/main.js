var noun = prompt ('Enter your favorite outdoor sport');

var verb = prompt ('Enter your favorite indoor sport');

var adjective = prompt ('Enter your favorite athlete');

var adverb = prompt ('Enter your favorite coach');

 


// console.log('Do you like playing '+verb+' with '+adjective+' and playing '+noun+' with  '+adverb+'? That\'s hilarious');

document.write('Do you like playing '+verb+' with '+adjective+' and playing '+noun+' with  '+adverb+'? That\'s hilarious');
 
 